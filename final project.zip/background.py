import pygame as pg
from pygame import *
from pygame.sprite import *


def background():
    bg = pg.image.load("images/background.jpg").convert()
    x = 0
